# FRB Patient-ID Export - frb_patient_id_20260923

Goi nay chua bo FRB da sinh tu split theo `patient_id`, dung de gui cho thay va Duy Hoang chay FKG-E/FKG/FKGS.

## Nguon split

- Split goc: `root_split/summary.json`
- Tong anh co nhan va co file tren dia: 1529
- Tong benh nhan: 897
- Train/test ngoai cung: 1208 anh / 729 benh nhan va 321 anh / 168 benh nhan
- `patient_overlap_count`: 0
- KFold trong train: 5 folds, moi fold da kiem tra overlap benh nhan bang 0

## Cach dung nhanh

Voi moi modality va fold, input FRB nam tai:

```text
fis_output/KFold_feature_selection_rerun_20260921/<DISPLAY_NAME>/fold_XX/FRB/TrainDataRule.csv
fis_output/KFold_feature_selection_rerun_20260921/<DISPLAY_NAME>/fold_XX/FRB/TestDataRule.csv
```

Neu code FKG-E/FKG cua Duy Hoang doc train tu `Rule_List.csv` nhu mot so script cu, file do cung nam canh thu muc `FRB`:

```text
fis_output/KFold_feature_selection_rerun_20260921/<DISPLAY_NAME>/fold_XX/Rule_List.csv
```

`dataset_manifests/KFold_feature_selection_rerun_20260921/<modality>/fold_XX/` chua `train_ids.csv`, `test_ids.csv`, `selected_features.csv`, va `metadata.json` de trace lai `image_id`/`patient_id`.

## Modality co trong goi

- table: `Diabetic Retinopathy Metadata Feature FT Selection KFold`
- image: `Diabetic Retinopathy Image Feature FT Selection KFold`
- fusion: `Diabetic Retinopathy Fusion Feature FT Selection KFold`
- fusion_filter: `Diabetic Retinopathy Fusion Feature Filter KFold`
- fusion_hadamard: `Diabetic Retinopathy Fusion Feature Hadamard KFold`
- fusion_tensor: `Diabetic Retinopathy Fusion Feature Tensor KFold`
- fusion_wrapper: `Diabetic Retinopathy Fusion Feature Wrapper KFold`

## Kiem chung

- `frb_validation_summary.csv`: tom tat tung modality/fold.
- `package_manifest.json`: manifest day du va cac duong dan nguon.
- Tat ca 35 modality-fold deu match voi `root_split/train_kfold/fold_*/train.csv` va `val.csv` theo `image_id`.
- Tong patient overlap trong cac fold: 0.

Luu y: `TrainDataRule.csv` co the nhieu dong hon `train_ids.csv` vi train fold co SMOTE; `TestDataRule.csv` bam dung validation fold.
